package bison.signalsrv;



import com.alibaba.fastjson.JSONObject;
import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;

import com.google.gson.JsonObject;
import jdk.nashorn.api.scripting.JSObject;
import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;
import org.kurento.client.*;
import org.kurento.client.IceCandidate;
import org.kurento.jsonrpc.JsonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * websocket服务器
 */
public class SignalServer extends WebSocketServer{

    private static final Logger log = LoggerFactory.getLogger(SignalServer.class);
    private static java.util.Map users = new java.util.HashMap<String, UserSession>();
    private KurentoClient kurento = KurentoClient.create("ws://localhost:8888/kurento");;



    public SignalServer(int port) {
        super(new InetSocketAddress(port));
    }
    /**
     * WebSocket连接关闭时调用
     */
    @Override
    public void onClose(WebSocket ws, int arg1, String arg2, boolean arg3) {
        System.out.println("------------------onClose-------------------");
    }

    /**
     * 错误发生时调用。
     */
    @Override
    public void onError(WebSocket ws, Exception e) {
        System.out.println("------------------onError-------------------");
        if(ws != null) {
        }
        e.printStackTrace();
    }

    private void initWebRtcEndpoint(final WebSocket session, String userName,
                                    final WebRtcEndpoint webRtcEp, String sdpOffer)
    {
        initBaseEventListeners(session, userName,  webRtcEp, "WebRtcEndpoint");
        initWebRtcEventListeners(session, userName, webRtcEp);

        webRtcEp.setName(userName);
        webRtcEp.setStunServerAddress("119.28.214.71");
        webRtcEp.setStunServerPort(3478);

        // Continue the SDP Negotiation: Generate an SDP Answer
        final String sdpAnswer = webRtcEp.processOffer(sdpOffer);

        log.info("[Handler::initWebRtcEndpoint] name: {}, SDP Offer from browser to KMS:\n{}",
                userName, sdpOffer);
        log.info("[Handler::initWebRtcEndpoint] name: {}, SDP Answer from KMS to browser:\n{}",
                userName, sdpAnswer);

        JsonObject message = new JsonObject();

        message.addProperty("type", "answer");
        message.addProperty("answer", sdpAnswer);
        session.send(message.toString());

    }

    /**
     * 接收到的消息
     */
    @Override
    public void onMessage(WebSocket ws, String msg) {
        System.out.println("收到消息："+msg);


        JSONObject msgJSON = null;
        try
        {
            msgJSON  = JSONObject.parseObject(msg);

        }
        catch (com.alibaba.fastjson.JSONException e)
        {
            msgJSON = null;
        }

        if (msgJSON == null)
        {
            ws.send("send:"+msg);
        }
        else
        {
            String type = msgJSON.getString("type");
            if (type == null) { type = "";}
            switch (type) {
                case "login": {

                    log.info("user login in as " + msgJSON.getString("name")+"\n");

                    JSONObject login = new JSONObject();
                    login.put("type", "login");
                    login.put("success", true);
                    ws.send(login.toJSONString());

                }
                break;
                case "offer": {

                    log.info("Sending offer to " + msgJSON.getString("name") + " from " + msgJSON.getString("myName")+"\n");

                    final UserSession user = new UserSession();
                    String sessionId = msgJSON.getString("myName");
                    users.put(sessionId, user);

                    log.info("[Handler::handleStart] Create Media Pipeline");

                    final MediaPipeline pipeline = kurento.createMediaPipeline();
                    user.setMediaPipeline(pipeline);

                    final WebRtcEndpoint webRtcEp =
                            new WebRtcEndpoint.Builder(pipeline).useDataChannels().build();//useDataChannels means it support data channel,optional
                            //new WebRtcEndpoint.Builder(pipeline).build();//useDataChannels means it support data channel,optional

                    user.setWebRtcEndpoint(webRtcEp);
                    webRtcEp.connect(webRtcEp);

                    String sdpOffer = msgJSON.getJSONObject("offer").getString("sdp");
                    initWebRtcEndpoint(ws, sessionId, webRtcEp, sdpOffer);

                    log.info("[Handler::handleStart] New WebRtcEndpoint: {}",
                            webRtcEp.getName());

                    startWebRtcEndpoint(webRtcEp);

                }
                break;
                case "candidate": {
                    log.info("Sending candidate to " + msgJSON.getString("name"));

                    final String sessionId = msgJSON.getString("myName");
                    if (!users.containsKey(sessionId)) {
                        log.warn("[Handler::handleAddIceCandidate] Skip, unknown user, id: {}",
                                sessionId);
                        return;
                    }

                    final UserSession user = (UserSession) users.get(sessionId);
                    final IceCandidate candidate =
                            new IceCandidate(msgJSON.getString("candidate"),
                                    msgJSON.getString("mid"),
                                    msgJSON.getInteger("mline"));

                    WebRtcEndpoint webRtcEp = user.getWebRtcEndpoint();
                    webRtcEp.addIceCandidate(candidate);
                }
                break;
                case "leave": {
                    log.info("Disconnectiong user from " + msgJSON.getString("myName"));
                    stopSession(ws, msgJSON.getString("myName"));
                }

                break;
                default:
                    JSONObject defaultMsg = new JSONObject();
                    defaultMsg.put("type", "error");
                    defaultMsg.put("message", "Unreconfized command : " + msgJSON.getString("type"));
                    ws.send(defaultMsg.toJSONString());
                    break;
            }
        }


        if(ws.isClosed()) {

        }
        else if (ws.isClosing()) {

        }
        else if(ws.isOpen()) {

        }
    }

    /**
     * websocket进行握手之后调用，并且给WebSocket写做准备
     * 通过握手可以获取请求头信息
     */
    @Override
    public void onOpen(WebSocket ws, ClientHandshake shake) {
        System.out.println("-----------------onOpen--------------------"+ws.isOpen()+"--"+ws.getReadyState()+"--"+ws.getAttachment());
        for(Iterator<String> it=shake.iterateHttpFields();it.hasNext();) {
            String key = it.next();
            System.out.println(key+":"+shake.getFieldValue(key));
        }
        JSONObject open = new JSONObject();
        open.put("status", "success");
        ws.send(open.toJSONString());
    }
    /**
     * 当服务器成功启动时调用
     */
    @Override
    public void onStart() {
        System.out.println("------------------onStart-------------------");
    }
    private void initBaseEventListeners(final WebSocket session,String userName,
                                        BaseRtpEndpoint baseRtpEp, final String className)
    {
        log.info("[Handler::initBaseEventListeners] name: {}, class: {}",
                baseRtpEp.getName(), className);

        // Event: Some error happened
        baseRtpEp.addErrorListener(new EventListener<ErrorEvent>() {
            @Override
            public void onEvent(ErrorEvent ev) {
                log.error("[{}::ErrorEvent] Error code {}: '{}', source: {}, timestamp: {}, tags: {}, description: {}",
                        className, ev.getErrorCode(), ev.getType(), ev.getSource().getName(),
                        ev.getTimestampMillis(), ev.getTags(), ev.getDescription());

                session.send("[Kurento] " + ev.getDescription());
                stopSession(session, userName);
            }
        });

        // Event: Media is flowing into this sink
        baseRtpEp.addMediaFlowInStateChangedListener(
                new EventListener<MediaFlowInStateChangedEvent>() {
                    @Override
                    public void onEvent(MediaFlowInStateChangedEvent ev) {
                        log.info("[{}::{}] source: {}, timestamp: {}, tags: {}, state: {}, padName: {}, mediaType: {}",
                                className, ev.getType(), ev.getSource().getName(), ev.getTimestampMillis(),
                                ev.getTags(), ev.getState(), ev.getPadName(), ev.getMediaType());
                    }
                });

        // Event: Media is flowing out of this source
        baseRtpEp.addMediaFlowOutStateChangedListener(
                new EventListener<MediaFlowOutStateChangedEvent>() {
                    @Override
                    public void onEvent(MediaFlowOutStateChangedEvent ev) {
                        log.info("[{}::{}] source: {}, timestamp: {}, tags: {}, state: {}, padName: {}, mediaType: {}",
                                className, ev.getType(), ev.getSource().getName(), ev.getTimestampMillis(),
                                ev.getTags(), ev.getState(), ev.getPadName(), ev.getMediaType());
                    }
                });

        // Event: [TODO write meaning of this event]
        baseRtpEp.addConnectionStateChangedListener(
                new EventListener<ConnectionStateChangedEvent>() {
                    @Override
                    public void onEvent(ConnectionStateChangedEvent ev) {
                        log.info("[{}::{}] source: {}, timestamp: {}, tags: {}, oldState: {}, newState: {}",
                                className, ev.getType(), ev.getSource().getName(), ev.getTimestampMillis(),
                                ev.getTags(), ev.getOldState(), ev.getNewState());
                    }
                });

        // Event: [TODO write meaning of this event]
        baseRtpEp.addMediaStateChangedListener(
                new EventListener<MediaStateChangedEvent>() {
                    @Override
                    public void onEvent(MediaStateChangedEvent ev) {
                        log.info("[{}::{}] source: {}, timestamp: {}, tags: {}, oldState: {}, newState: {}",
                                className, ev.getType(), ev.getSource().getName(), ev.getTimestampMillis(),
                                ev.getTags(), ev.getOldState(), ev.getNewState());
                    }
                });

        // Event: This element will (or will not) perform media transcoding
        baseRtpEp.addMediaTranscodingStateChangedListener(
                new EventListener<MediaTranscodingStateChangedEvent>() {
                    @Override
                    public void onEvent(MediaTranscodingStateChangedEvent ev) {
                        log.info("[{}::{}] source: {}, timestamp: {}, tags: {}, state: {}, binName: {}, mediaType: {}",
                                className, ev.getType(), ev.getSource().getName(), ev.getTimestampMillis(),
                                ev.getTags(), ev.getState(), ev.getBinName(), ev.getMediaType());
                    }
                });
    }

    private void initWebRtcEventListeners(final WebSocket session, String userName,
                                          final WebRtcEndpoint webRtcEp)
    {
        log.info("[Handler::initWebRtcEventListeners] name: {}",
                webRtcEp.getName());


        // Event: The ICE backend found a local candidate during Trickle ICE
        webRtcEp.addIceCandidateFoundListener(
                new EventListener<IceCandidateFoundEvent>() {
                    @Override
                    public void onEvent(IceCandidateFoundEvent ev) {
                        log.debug("[WebRtcEndpoint::{}] source: {}, timestamp: {}, tags: {}, candidate: {}",
                                ev.getType(), ev.getSource().getName(), ev.getTimestampMillis(),
                                ev.getTags(), JsonUtils.toJson(ev.getCandidate()));

                        JsonObject message = new JsonObject();
                        message.addProperty("type", "candidate");
                        message.add("candidate", JsonUtils.toJsonObject(ev.getCandidate()));
                        log.debug("send candidate to client:" + message.toString());
                        session.send(message.toString());
                    }
                });

        // Event: The ICE backend changed state
        webRtcEp.addIceComponentStateChangedListener(
                new EventListener<IceComponentStateChangedEvent>() {
                    @Override
                    public void onEvent(IceComponentStateChangedEvent ev) {
                        log.debug("[WebRtcEndpoint::{}] source: {}, timestamp: {}, tags: {}, streamId: {}, componentId: {}, state: {}",
                                ev.getType(), ev.getSource().getName(), ev.getTimestampMillis(),
                                ev.getTags(), ev.getStreamId(), ev.getComponentId(), ev.getState());
                    }
                });

        // Event: The ICE backend finished gathering ICE candidates
        webRtcEp.addIceGatheringDoneListener(
                new EventListener<IceGatheringDoneEvent>() {
                    @Override
                    public void onEvent(IceGatheringDoneEvent ev) {
                        log.info("[WebRtcEndpoint::{}] source: {}, timestamp: {}, tags: {}",
                                ev.getType(), ev.getSource().getName(), ev.getTimestampMillis(),
                                ev.getTags());
                    }
                });

        // Event: The ICE backend selected a new pair of ICE candidates for use
        webRtcEp.addNewCandidatePairSelectedListener(
                new EventListener<NewCandidatePairSelectedEvent>() {
                    @Override
                    public void onEvent(NewCandidatePairSelectedEvent ev) {
                        log.info("[WebRtcEndpoint::{}] name: {}, timestamp: {}, tags: {}, streamId: {}, local: {}, remote: {}",
                                ev.getType(), ev.getSource().getName(), ev.getTimestampMillis(),
                                ev.getTags(), ev.getCandidatePair().getStreamID(),
                                ev.getCandidatePair().getLocalCandidate(),
                                ev.getCandidatePair().getRemoteCandidate());
                    }
                });
    }
    private void stopSession(final WebSocket session, String userName)
    {
        // Remove the user session and release all resources

        final UserSession user = (UserSession)( users.remove(userName));
        if (user != null) {
            MediaPipeline mediaPipeline = user.getMediaPipeline();
            if (mediaPipeline != null) {
                log.info("[Handler::stop] Release the Media Pipeline");
                mediaPipeline.release();
            }
        }
    }
    private void startWebRtcEndpoint(WebRtcEndpoint webRtcEp)
    {
        // Calling gatherCandidates() is when the Endpoint actually starts working.
        // In this tutorial, this is emphasized for demonstration purposes by
        // launching the ICE candidate gathering in its own method.
        webRtcEp.gatherCandidates();
    }

}

