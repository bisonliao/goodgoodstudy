package bison.signalsrv;

public class App {
    public static void main( String[] args )
    {
        new SignalServer(8090).start();
        System.out.println( "Hello World!" );
    }
}
